# MahanT-Movie

A mobile-friendly Persian movie/TV discovery web app starter.

## Run
Open `index.html` in a browser, or publish this folder using GitHub Pages.

## Live metadata
Open Settings (⚙) and enter your TMDB API Read Access Token. This loads trending movies and TV shows from TMDB. The demo falls back to sample entries if no token is configured.

TMDB API settings: https://www.themoviedb.org/settings/api

## Important
- This is a web app starter, not an Android APK.
- It displays metadata/posters; it does not host or provide unauthorized movie streams/downloads.
- The token is stored in the current browser's local storage. For a public production service, proxy API requests through a backend so the token is not exposed.
- Movie metadata is provided by TMDB; attribution and TMDB branding requirements should be reviewed before public release.
